# AI100 — HW8: Lab A and Lab B

This repository contains two independent lab folders. Both Jupyter notebooks and their displayed figures/tables/checkpoint outputs have been saved after execution.

## Folders

- `student_score_lab/`: data preprocessing, linear regression, and logistic regression (3 executed notebooks).
- `fraud_tree_lab/`: decision trees with Gini and entropy (1 executed notebook, saved after the Gini run).

## Reproduce the results

From within each lab's folder, install its `requirements.txt` and start `jupyter lab`. For Lab A, run `notebooks/01_fix_the_pipeline.ipynb` before 02 and 03. For Lab B, run `notebooks/fraud_tree_gini_vs_entropy.ipynb` with `CRITERION="gini"` (saved final setting) or temporarily change to `"entropy"`. Always use **Restart Kernel and Run All Cells**, then save outputs.

The files retain the original labs' `src`, `data`, and requirements, along with completed notebook cells. Lab A's `outputs/scoreboard.csv` contains the baseline and all nine cumulative patch runs.

## Evaluation snapshots (synthetic data)

| Experiment | Result |
|---|---|
| Student score baseline, before patches | R² = 0.752, AUC = 0.913 |
| Student score after 9 patches | R² = 0.873, MAE = 4.542, AUC = 0.972 |
| Fraud tree (Gini, depth 6), test | precision = 0.832, recall = 0.473 |
| Fraud tree (Entropy, depth 6), test | precision = 0.919, recall = 0.519 |

**Source-file discrepancy:** The provided Fraud Tree notebook contains only four checkpoint calls (`Q1`, `Q3`, `Q4`, `Q5`); there is no `Q2` question or check cell, even though the provided `quiz_answers.json` has a Q2 key and the README says five questions. That missing prompt was not invented.

## Submission

Publish this folder's **two lab subfolders** in a **public** GitHub repository. Submit **two GitHub folder URLs** (one URL for `student_score_lab/` and another for `fraud_tree_lab/`), not the ZIP URL and not just the repository's home page. Check links in a logged-out browser window to confirm they open without sign-in.
